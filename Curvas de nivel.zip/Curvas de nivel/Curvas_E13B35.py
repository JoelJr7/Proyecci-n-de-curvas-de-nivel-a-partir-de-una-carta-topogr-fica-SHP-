
# coding: utf-8

# In[2]:

#cargamos todas las bibliotecas que ocuparemos en el desarrollo del proyecto
import folium
import shapefile
import json
from pyproj import Proj


# In[3]:

#creamos un bucle para poder generar un archivo geojson.
# el reader se encarga de leer el archivo, y para que lo pueda reconocer lo guardamos en el disco c.
reader = shapefile.Reader("c:\\curva_nivel50_l.shp")
#cargamos las lineas del archivo.
fields = reader.fields[1:]
#una vez ya cargadas las lineas las guarrdaremos en una nueva variable para adjuntarlas porteriormente.
field_names = [field[0] for field in fields]
#Con el buffer almacenaremos los datos en el archivo geojson, el buffer es un arreglo temporal de almacenamiento.
buffer = []
# con el bucle for le daremos la estructura a nuestro archivo json
for sr in reader.shapeRecords():
    #en la variable atr estan guardadas las coordenadas y las propiedades del archivo.
    atr = dict(zip(field_names, sr.record))
    #con geom guardaremos la interface del archivo, para despues agregarselo
    geom = sr.shape.__geo_interface__
    #para finalizar con la creacion del json se agregara todo al buffer
    buffer.append(dict(type="Feature",geometry=geom, properties=atr)) 
    
#de la biblioteca json importaremos el comando dumps para que nos permita poder abrir nuestro archivo geojson y guardarlo en home de notebook.
from json import dumps
geojson = open("curva.json", "w")
geojson.write(dumps({"type": "FeatureCollection","features": buffer}, indent=2) + "\n")
geojson.close()


# In[4]:

#Cargamos el archivo geojson
with open('curva.json') as file:
    data=json.load(file)


# In[5]:

#con un bucle for recorreremos una por una las coordenadas pasandolas de UTM a coordenadas geograficas, esto podra ser elaborado con la biblioteca pyproj.
for i in range(len(data["features"])):
    for j in range (len(data["features"][i]["geometry"]["coordinates"])):
        x=data["features"][i]["geometry"]["coordinates"][j][0]
        y=data["features"][i]["geometry"]["coordinates"][j][1]
        myProj = Proj("+proj=utm +zone=13N, +north +ellps=WGS84 +datum=WGS84 +units=m +no_defs")
#invertimos las coordenadas para que puedan ser legibles en folium y las guardamos en variables (lat, lon)
        lon, lat = myProj(x, y, inverse=True)
        data["features"][i]["geometry"]["coordinates"][j][0]=lat
        data["features"][i]["geometry"]["coordinates"][j][1]=lon


# In[6]:

#se crea un mapa con el nombre curvas, se coloca su coordenada de inicio, el zoom adecuado para una mejor visualizacion y el tipo de mapa.
curvas = folium.Map(location=[19.3597,-103.4458], zoom_start=11, tiles='Stamen Terrain')

#se agregan las curvas de nivel en el mapa, le damos el color respectivo, el grosor y lo opaco que tendran las lineas y las agregamos al mapa.
for i in range(len(data["features"])):
    folium.PolyLine(data["features"][i]["geometry"]["coordinates"], color="red", weight=1, opacity=1).add_to(curvas)

#imprimimos el mapa
curvas


# In[ ]:



